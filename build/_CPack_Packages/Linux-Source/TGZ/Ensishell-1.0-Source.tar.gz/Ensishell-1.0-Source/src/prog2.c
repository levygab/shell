#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <string.h>

void lecture (char* c) {
  /*
  fct qui lit les commandes sur l'entree standart. Pour ca on utilise
  la fct parsecmb qui lit une commande
  */
  cmdline* sequence ;
  
}
